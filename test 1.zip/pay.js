document.getElementById('payment-form').addEventListener('submit', function(event) {
    event.preventDefault();
    alert('Payment submitted successfully!');
});
